<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Orders\Order;
use App\Models\Orders\OrderLine;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    /**
     * List customer orders
     */
    public function index()
    {
        $customer = Auth::user()->customer;

        $orders = Order::query()
            ->where('customer_id', $customer->id)
            ->latest()
            ->get();

        return view('customer.orders.index', compact('orders'));
    }

    /**
     * Step 1: Build order (draft)
     */
    public function create()
    {
        $customer = Auth::user()->customer;

        // Draft order is created immediately (safe & intentional)
        $order = Order::create([
            'company_id'     => $customer->company_id,
            'customer_id'    => $customer->id,
            'order_number'   => $this->generateOrderNumber(),
            'source_channel' => 'customer_portal',
            'status'         => 'draft',
            'created_by'     => Auth::id(),
        ]);

        // Portfolio is the ONLY source of selectable products
        $portfolioItems = $customer->portfolioItems()
            ->with(['product', 'productVariation'])
            ->get();

        return view('customer.orders.build', compact('order', 'portfolioItems'));
    }

    /**
     * Step 2: Review order before submission
     */
    public function review(Order $order)
    {
        $this->authorizeCustomerOrder($order);

        if (! $order->isEditableByCustomer()) {
            abort(403);
        }

        $order->load('lines.product', 'lines.productVariation');

        return view('customer.orders.review', compact('order'));
    }

    /**
     * Show order (read-only after submit)
     */
    public function show(Order $order)
    {
        $this->authorizeCustomerOrder($order);

        $order->load('lines.product', 'lines.productVariation');

        return view('customer.orders.show', compact('order'));
    }

    /**
     * -------------------------------------
     * Internal helpers
     * -------------------------------------
     */

    protected function authorizeCustomerOrder(Order $order): void
    {
        $customer = Auth::user()->customer;

        if ($order->customer_id !== $customer->id) {
            abort(403);
        }
    }

    protected function generateOrderNumber(): string
    {
        return 'ORD-' . now()->format('Ymd') . '-' . strtoupper(str()->random(6));
    }
}
