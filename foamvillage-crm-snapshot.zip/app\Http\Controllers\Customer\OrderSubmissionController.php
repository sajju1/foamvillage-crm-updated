<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Orders\Order;
use Illuminate\Support\Facades\Auth;

class OrderSubmissionController extends Controller
{
    /**
     * Submit a draft order
     */
    public function submit(Order $order)
    {
        $this->authorizeCustomerOrder($order);

        // Only draft orders can be submitted
        if (! $order->isDraft()) {
            abort(403);
        }

        // Order must have at least one line
        if ($order->lines()->count() === 0) {
            return redirect()
                ->back()
                ->withErrors(['order' => 'You cannot submit an empty order.']);
        }

        $order->update([
            'status'       => 'submitted',
            'submitted_at' => now(),
        ]);

        return redirect()
            ->route('customer.orders.show', $order)
            ->with('success', 'Order submitted successfully.');
    }

    /**
     * -------------------------------------
     * Internal helpers
     * -------------------------------------
     */

    protected function authorizeCustomerOrder(Order $order): void
    {
        $customer = Auth::user()->customer;

        if ($order->customer_id !== $customer->id) {
            abort(403);
        }
    }
}
