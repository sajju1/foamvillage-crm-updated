<?php

namespace App\Http\Controllers\Staff;

use App\Http\Controllers\Controller;
use App\Models\Orders\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    /**
     * List all orders (staff view)
     */
    public function index()
    {
        $orders = Order::query()
            ->with('customer')
            ->latest()
            ->get();

        return view('staff.orders.index', compact('orders'));
    }

    /**
     * Show order details (staff view)
     */
    public function show(Order $order)
    {
        $order->load([
            'customer',
            'lines.product',
            'lines.productVariation',
        ]);

        return view('staff.orders.show', compact('order'));
    }
}
