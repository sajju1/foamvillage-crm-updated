<?php

use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        // This migration is intentionally left empty.
        // The customer_product_portfolio table is created
        // by an earlier migration.
    }

    public function down(): void
    {
        // No rollback needed.
    }
};
