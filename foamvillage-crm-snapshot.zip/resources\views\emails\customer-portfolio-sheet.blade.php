<p>Dear {{ $customerBlock['contact_name'] }},</p>

<p>
    Please find attached your latest product portfolio sheet.
</p>

<p>
    If you have any questions, please contact us.
</p>

<p>
    Kind regards,<br>
    {{ $companyBlock['name'] }}
</p>
