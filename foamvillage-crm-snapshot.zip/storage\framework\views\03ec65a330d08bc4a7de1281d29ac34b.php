
<div x-show="showOffers" x-cloak
     class="fixed inset-0 z-50 flex items-center justify-center">

    
    <div class="fixed inset-0 bg-black bg-opacity-50"
         @click="showOffers = false"></div>

    
    <div class="bg-white w-full max-w-lg rounded shadow-lg p-6 relative"
         @click.stop>

        <h3 class="text-lg font-semibold mb-1">
            Offers
        </h3>

        <p class="text-sm text-gray-600 mb-4">
            <?php echo e($entry->sellable_label); ?>

        </p>

        
        <?php if($entry->offers->count() === 0): ?>
            <div class="border rounded p-4 text-sm text-gray-600 bg-gray-50 mb-4">
                No offers configured for this product yet.
            </div>
        <?php else: ?>
            <div class="space-y-3 mb-4">
                <?php $__currentLoopData = $entry->offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded p-3 text-sm">
                        <div class="flex justify-between items-center">
                            <div>
                                <div class="font-medium">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $offer->offer_type))); ?>

                                </div>
                                <div class="text-xs text-gray-500">
                                    <?php echo e($offer->effective_from->format('d M Y')); ?>

                                    <?php if($offer->effective_to): ?>
                                        → <?php echo e($offer->effective_to->format('d M Y')); ?>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if($offer->is_active): ?>
                                <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                                    Active
                                </span>
                            <?php else: ?>
                                <span class="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded">
                                    Inactive
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        
        <form method="POST"
              action="<?php echo e(route('customers.portfolio.offers.store', $entry)); ?>"
              class="space-y-3 border-t pt-4">
            <?php echo csrf_field(); ?>

            <div>
                <label class="text-sm font-medium">Offer type</label>
                <select name="offer_type" required
                        class="border rounded w-full px-2 py-1 text-sm">
                    <option value="fixed_price">Fixed price</option>
                    <option value="percentage_discount">Percentage discount</option>
                    <option value="fixed_discount">Fixed discount</option>
                </select>
            </div>

            <div>
                <label class="text-sm font-medium">Fixed price (£)</label>
                <input type="number" name="fixed_price" step="0.01"
                       class="border rounded w-full px-2 py-1 text-sm">
            </div>

            <div>
                <label class="text-sm font-medium">Percentage (%)</label>
                <input type="number" name="percentage" step="0.01"
                       class="border rounded w-full px-2 py-1 text-sm">
            </div>

            <div>
                <label class="text-sm font-medium">Discount amount (£)</label>
                <input type="number" name="discount_amount" step="0.01"
                       class="border rounded w-full px-2 py-1 text-sm">
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-sm font-medium">Effective from</label>
                    <input type="date" name="effective_from" required
                           class="border rounded w-full px-2 py-1 text-sm">
                </div>

                <div>
                    <label class="text-sm font-medium">Effective to</label>
                    <input type="date" name="effective_to"
                           class="border rounded w-full px-2 py-1 text-sm">
                </div>
            </div>

            <div class="flex justify-end gap-2 pt-2">
                <button type="button"
                        class="px-3 py-1 border rounded text-sm"
                        @click="showOffers = false">
                    Close
                </button>

                <button type="submit"
                        class="px-3 py-1 bg-blue-600 text-white rounded text-sm">
                    Add Offer
                </button>
            </div>
        </form>

    </div>
</div>
<?php /**PATH C:\Users\sajja\Desktop\new-foamvillage-crm\resources\views/customers/_offers.blade.php ENDPATH**/ ?>