<?php
    $registered = $customer->addresses->where('address_type', 'registered')->where('is_active', true)->first();
    $billing = $customer->addresses->where('address_type', 'billing')->where('is_active', true)->first();

    $deliveryActive = $customer->addresses->where('address_type', 'delivery')->where('is_active', true);
    $deliveryInactive = $customer->addresses->where('address_type', 'delivery')->where('is_active', false);

    $defaultDelivery = $deliveryActive->firstWhere('is_default', true);

    $fields = ['address_line1', 'address_line2', 'address_line3', 'city', 'state_region', 'postcode', 'country'];

    $fmt = function ($a) {
        if (!$a) {
            return '—';
        }
        $parts = array_filter([
            $a->address_line1,
            $a->address_line2,
            $a->address_line3,
            trim(($a->city ?? '') . ($a->state_region ?? '' ? ', ' . $a->state_region : '')),
            $a->postcode,
            $a->country,
        ]);
        return implode('<br>', $parts);
    };
?>

<div x-data="{ regOpen: false, billOpen: false, delAddOpen: false, delManageOpen: false }" class="bg-white shadow rounded p-6 space-y-4">

    <div class="flex items-center justify-between border-b pb-3">
        <h2 class="text-lg font-semibold">Addresses</h2>
        <div class="text-xs text-gray-500">
            Registered + Billing required • Multiple delivery allowed • One default
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

        
        <div class="border rounded p-4 space-y-3">
            <div class="flex items-start justify-between">
                <div>
                    <div class="font-semibold">Registered</div>
                    <div class="text-xs text-gray-500">Required</div>
                </div>

                <button type="button" class="text-sm text-blue-600 hover:underline" @click="regOpen = true">
                    <?php echo e($registered ? 'Replace' : 'Add'); ?>

                </button>
            </div>

            <?php if($registered): ?>
                <div class="text-sm bg-gray-50 border rounded p-3"><?php echo $fmt($registered); ?></div>
            <?php else: ?>
                <div class="text-sm text-yellow-700 bg-yellow-50 border border-yellow-200 p-3 rounded">
                    Registered address is required.
                </div>
            <?php endif; ?>
        </div>

        
        <div class="border rounded p-4 space-y-3">
            <div class="flex items-start justify-between">
                <div>
                    <div class="font-semibold">Billing</div>
                    <div class="text-xs text-gray-500">Required</div>
                </div>

                <div class="flex items-center gap-3">
                    <?php if($registered): ?>
                        
                        <form method="POST" action="<?php echo e(route('customers.addresses.store', $customer)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="address_type" value="billing">
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="<?php echo e($field); ?>" value="<?php echo e($registered->$field); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="text-sm text-blue-600 hover:underline">
                                Copy from registered
                            </button>
                        </form>
                    <?php endif; ?>

                    <button type="button" class="text-sm text-blue-600 hover:underline" @click="billOpen = true">
                        <?php echo e($billing ? 'Replace' : 'Add'); ?>

                    </button>
                </div>
            </div>

            <?php if($billing): ?>
                <div class="text-sm bg-gray-50 border rounded p-3"><?php echo $fmt($billing); ?></div>
            <?php else: ?>
                <div class="text-sm text-yellow-700 bg-yellow-50 border border-yellow-200 p-3 rounded">
                    Billing address is required.
                </div>
            <?php endif; ?>
        </div>

        
        <div class="border rounded p-4 space-y-3">
            <div class="flex items-start justify-between">
                <div>
                    <div class="font-semibold">Delivery</div>
                    <div class="text-xs text-gray-500">
                        Active: <?php echo e($deliveryActive->count()); ?> • History: <?php echo e($deliveryInactive->count()); ?>

                    </div>
                </div>

                <div class="flex items-center gap-3">
                    <?php if($registered): ?>
                        
                        <form method="POST" action="<?php echo e(route('customers.addresses.store', $customer)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="address_type" value="delivery">
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="<?php echo e($field); ?>" value="<?php echo e($registered->$field); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="text-sm text-blue-600 hover:underline">
                                Copy from registered
                            </button>
                        </form>
                    <?php endif; ?>

                    <button type="button" class="text-sm text-blue-600 hover:underline" @click="delAddOpen = true">
                        Add
                    </button>

                    <button type="button" class="text-sm text-blue-600 hover:underline" @click="delManageOpen = true">
                        Manage
                    </button>
                </div>
            </div>

            <?php if($defaultDelivery): ?>
                <div class="text-sm bg-gray-50 border rounded p-3">
                    <div class="flex items-start justify-between gap-3">
                        <div class="flex-1"><?php echo $fmt($defaultDelivery); ?></div>
                        <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">Default</span>
                    </div>
                </div>
            <?php elseif($deliveryActive->isEmpty()): ?>
                <div class="text-sm text-yellow-700 bg-yellow-50 border border-yellow-200 p-3 rounded">
                    At least one delivery address is required.
                </div>
            <?php else: ?>
                <div class="text-sm bg-gray-50 border rounded p-3 text-gray-600">
                    No default set (active delivery addresses exist).
                </div>
            <?php endif; ?>

            <?php if($deliveryActive->count() > 1): ?>
                <div class="text-xs text-gray-500">
                    Other active delivery addresses hidden — use “Manage”.
                </div>
            <?php endif; ?>
        </div>

    </div>

    
    <div x-show="regOpen || billOpen || delAddOpen || delManageOpen" x-cloak class="fixed inset-0 z-40 bg-black/50"
        @click="regOpen=false; billOpen=false; delAddOpen=false; delManageOpen=false;">
    </div>

    
    <div x-show="regOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="bg-white w-full max-w-2xl rounded shadow-lg" @click.stop>
            <div class="px-6 py-4 border-b flex items-center justify-between">
                <h3 class="font-semibold"><?php echo e($registered ? 'Replace' : 'Add'); ?> Registered Address</h3>
                <button type="button" class="text-xl text-gray-500 hover:text-gray-700"
                    @click="regOpen=false">×</button>
            </div>

            <form method="POST" action="<?php echo e(route('customers.addresses.store', $customer)); ?>" class="p-6 space-y-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="address_type" value="registered">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 1</label>
                        <input name="address_line1" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 2</label>
                        <input name="address_line2" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 3</label>
                        <input name="address_line3" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">City</label>
                        <input name="city" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">State / Region</label>
                        <input name="state_region" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Postcode</label>
                        <input name="postcode" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-xs text-gray-600 mb-1">Country</label>
                        <input name="country" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                </div>

                <div class="flex justify-end gap-3">
                    <button type="button" class="px-4 py-2 border rounded" @click="regOpen=false">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">
                        <?php echo e($registered ? 'Replace' : 'Save'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <div x-show="billOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="bg-white w-full max-w-2xl rounded shadow-lg" @click.stop>
            <div class="px-6 py-4 border-b flex items-center justify-between">
                <h3 class="font-semibold"><?php echo e($billing ? 'Replace' : 'Add'); ?> Billing Address</h3>
                <button type="button" class="text-xl text-gray-500 hover:text-gray-700"
                    @click="billOpen=false">×</button>
            </div>

            <form method="POST" action="<?php echo e(route('customers.addresses.store', $customer)); ?>" class="p-6 space-y-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="address_type" value="billing">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 1</label>
                        <input name="address_line1" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 2</label>
                        <input name="address_line2" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 3</label>
                        <input name="address_line3" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">City</label>
                        <input name="city" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">State / Region</label>
                        <input name="state_region" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Postcode</label>
                        <input name="postcode" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-xs text-gray-600 mb-1">Country</label>
                        <input name="country" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                </div>

                <div class="flex justify-end gap-3">
                    <button type="button" class="px-4 py-2 border rounded" @click="billOpen=false">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">
                        <?php echo e($billing ? 'Replace' : 'Save'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <div x-show="delAddOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="bg-white w-full max-w-2xl rounded shadow-lg" @click.stop>
            <div class="px-6 py-4 border-b flex items-center justify-between">
                <h3 class="font-semibold">Add Delivery Address</h3>
                <button type="button" class="text-xl text-gray-500 hover:text-gray-700"
                    @click="delAddOpen=false">×</button>
            </div>

            <form method="POST" action="<?php echo e(route('customers.addresses.store', $customer)); ?>" class="p-6 space-y-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="address_type" value="delivery">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 1</label>
                        <input name="address_line1" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 2</label>
                        <input name="address_line2" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Address line 3</label>
                        <input name="address_line3" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">City</label>
                        <input name="city" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">State / Region</label>
                        <input name="state_region" class="w-full border rounded px-3 py-2 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">Postcode</label>
                        <input name="postcode" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-xs text-gray-600 mb-1">Country</label>
                        <input name="country" class="w-full border rounded px-3 py-2 text-sm" required>
                    </div>
                </div>

                <label class="flex items-center gap-2 text-sm">
                    <input type="checkbox" name="is_default" value="1">
                    Set as default delivery address
                </label>

                <div class="flex justify-end gap-3">
                    <button type="button" class="px-4 py-2 border rounded" @click="delAddOpen=false">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">
                        Add
                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <div x-show="delManageOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="bg-white w-full max-w-4xl rounded shadow-lg flex flex-col max-h-[85vh]" @click.stop>
            <div class="px-6 py-4 border-b flex items-center justify-between">
                <h3 class="font-semibold">Manage Delivery Addresses</h3>
                <button type="button" class="text-xl text-gray-500 hover:text-gray-700"
                    @click="delManageOpen=false">×</button>
            </div>

            <div class="p-6 overflow-y-auto space-y-6">

                <div>
                    <div class="font-semibold mb-2">Active</div>

                    <?php if($deliveryActive->isEmpty()): ?>
                        <div class="text-sm text-gray-600 bg-gray-50 border rounded p-3">
                            No active delivery addresses.
                        </div>
                    <?php else: ?>
                        <table class="w-full text-sm border">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="p-2 text-left">Address</th>
                                    <th class="p-2 text-left">Postcode</th>
                                    <th class="p-2 text-left">Country</th>
                                    <th class="p-2 text-left">Default</th>
                                    <th class="p-2 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $deliveryActive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-t">
                                        <td class="p-2">
                                            <?php echo e($delivery->address_line1); ?>, <?php echo e($delivery->city); ?>

                                        </td>

                                        <td class="p-2"><?php echo e($delivery->postcode); ?></td>
                                        <td class="p-2"><?php echo e($delivery->country); ?></td>

                                        <td class="p-2">
                                            <?php if($delivery->is_default): ?>
                                                <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                                                    Default
                                                </span>
                                            <?php else: ?>
                                                —
                                            <?php endif; ?>
                                        </td>

                                        <td class="p-2 text-right space-x-2">

                                            
                                            <?php if(!$delivery->is_default): ?>
                                                <form method="POST"
                                                    action="<?php echo e(route('customers.addresses.update', $delivery)); ?>"
                                                    class="inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>

                                                    
                                                    <input type="hidden" name="address_line1"
                                                        value="<?php echo e($delivery->address_line1); ?>">
                                                    <input type="hidden" name="address_line2"
                                                        value="<?php echo e($delivery->address_line2); ?>">
                                                    <input type="hidden" name="address_line3"
                                                        value="<?php echo e($delivery->address_line3); ?>">
                                                    <input type="hidden" name="city"
                                                        value="<?php echo e($delivery->city); ?>">
                                                    <input type="hidden" name="state_region"
                                                        value="<?php echo e($delivery->state_region); ?>">
                                                    <input type="hidden" name="postcode"
                                                        value="<?php echo e($delivery->postcode); ?>">
                                                    <input type="hidden" name="country"
                                                        value="<?php echo e($delivery->country); ?>">

                                                    
                                                    <input type="hidden" name="is_default" value="1">

                                                    <button class="text-blue-600 text-xs hover:underline">
                                                        Set default
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            
                                            <?php if(!$delivery->is_default): ?>
                                                <form method="POST"
                                                    action="<?php echo e(route('customers.addresses.deactivate', $delivery)); ?>"
                                                    class="inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                    <button class="text-red-600 text-xs">
                                                        Deactivate
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-xs text-gray-400">
                                                    Default cannot be deactivated
                                                </span>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    <?php endif; ?>
                </div>

                <div>
                    <div class="font-semibold mb-2">History</div>
                    <?php if($deliveryInactive->isEmpty()): ?>
                        <div class="text-sm text-gray-600 bg-gray-50 border rounded p-3">
                            No delivery history.
                        </div>
                    <?php else: ?>
                        <div class="space-y-2">
                            <?php $__currentLoopData = $deliveryInactive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="border rounded p-3 text-sm bg-gray-50">
                                    <?php echo $fmt($addr); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

            <div class="px-6 py-4 border-t flex justify-end gap-3">
                <button type="button" class="px-4 py-2 border rounded" @click="delManageOpen=false">Close</button>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\sajja\Desktop\new-foamvillage-crm\resources\views/customers/_addresses.blade.php ENDPATH**/ ?>