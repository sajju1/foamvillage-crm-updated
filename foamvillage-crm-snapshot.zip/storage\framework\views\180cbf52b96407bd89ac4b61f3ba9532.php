<div x-data="{ open: false }" class="bg-white p-6 rounded shadow space-y-4">

    <div class="flex justify-between items-center">
        <h2 class="text-lg font-semibold">
            Customer Product Portfolio
        </h2>

        <button type="button" class="bg-blue-600 text-white px-3 py-1 rounded text-sm" @click="open = true">
            + Add Product
        </button>
    </div>

    
    <div class="flex items-center gap-2 mb-4">

        <a href="<?php echo e(route('customers.portfolio.print', $customer)); ?>" target="_blank"
            class="px-3 py-2 text-sm bg-gray-200 rounded hover:bg-gray-300">
            🖨 Print
        </a>

        <a href="<?php echo e(route('customers.portfolio.pdf', $customer)); ?>" target="_blank"
            class="px-3 py-2 text-sm bg-gray-200 rounded hover:bg-gray-300">
            📄 Download PDF
        </a>

        <a href="<?php echo e(route('customers.portfolio.email', $customer)); ?>"
            class="px-3 py-2 text-sm bg-gray-200 rounded hover:bg-gray-300"
            onclick="return confirm('Email portfolio sheet to customer?')">
            ✉ Email
        </a>

    </div>


    <?php if($customer->portfolio->count() === 0): ?>
        <div class="text-sm text-gray-600 bg-gray-50 border rounded p-4">
            No products assigned to this customer yet.
        </div>
    <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm border">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="p-2 text-left">Item</th>
                        <th class="p-2 text-right">Product Standard Price</th>
                        <th class="p-2 text-right">Customer Pricing</th>
                        <th class="p-2 text-center">Offers</th>
                        <th class="p-2 text-center">Status</th>
                        <th class="p-2 text-right">Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $customer->portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t" x-data="{ editing: false, showOffers: false }">

                            
                            <td class="p-2 font-medium">
                                <?php echo e($entry->sellable_label); ?>

                            </td>

                            
                            <td class="p-2 text-right">
                                <?php if($entry->variation && isset($entry->variation->standard_price)): ?>
                                    £<?php echo e(number_format($entry->variation->standard_price, 2)); ?>

                                <?php elseif($entry->product && isset($entry->product->simple_price)): ?>
                                    £<?php echo e(number_format($entry->product->simple_price, 2)); ?>

                                <?php else: ?>
                                    <span class="text-gray-400">—</span>
                                <?php endif; ?>
                            </td>

                            
                            <td class="p-2 text-right">
                                <?php if($entry->pricing_type === 'fixed'): ?>
                                    £<?php echo e(number_format($entry->agreed_price, 2)); ?>

                                <?php else: ?>
                                    <span class="italic text-gray-500">
                                        Formula pricing
                                    </span>
                                <?php endif; ?>
                            </td>

                            
                            <td class="p-2 text-center space-y-1">

                                <?php
                                    $activeOffer = $entry->offers
                                        ->where('is_active', true)
                                        ->sortByDesc('effective_from')
                                        ->first();
                                ?>

                                <?php if($activeOffer): ?>
                                    <div class="text-xs font-medium text-green-700">
                                        <?php switch($activeOffer->offer_type):
                                            case ('fixed_price'): ?>
                                                £<?php echo e(number_format($activeOffer->fixed_price, 2)); ?>

                                            <?php break; ?>

                                            <?php case ('percentage_discount'): ?>
                                                <?php echo e($activeOffer->percentage); ?>% off
                                            <?php break; ?>

                                            <?php case ('fixed_discount'): ?>
                                                £<?php echo e(number_format($activeOffer->discount_amount, 2)); ?> off
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    </div>

                                    <div class="text-[11px] text-gray-500">
                                        <?php if($activeOffer->effective_to): ?>
                                            Until <?php echo e($activeOffer->effective_to->format('d M Y')); ?>

                                        <?php else: ?>
                                            No expiry
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="text-xs text-gray-400">—</div>
                                <?php endif; ?>

                                
                                <button type="button" class="text-blue-600 text-xs underline"
                                    @click="showOffers = true">
                                    View / Add
                                </button>

                                
                                <?php echo $__env->make('customers._offers', ['entry' => $entry], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                            </td>

                            
                            <td class="p-2 text-center">
                                <?php if($entry->is_active): ?>
                                    <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                                        Active
                                    </span>
                                <?php else: ?>
                                    <span class="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded">
                                        Inactive
                                    </span>
                                <?php endif; ?>
                            </td>

                            
                            <td class="p-2 text-right">
                                <form method="POST" action="<?php echo e(route('customers.portfolio.deactivate', $entry)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="text-red-600 text-sm">
                                        Deactivate
                                    </button>
                                </form>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    
    <div x-show="open" x-cloak>
        <?php echo $__env->make('customers.portfolio.add-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

</div>
<?php /**PATH C:\Users\sajja\Desktop\new-foamvillage-crm\resources\views/customers/_portfolio.blade.php ENDPATH**/ ?>