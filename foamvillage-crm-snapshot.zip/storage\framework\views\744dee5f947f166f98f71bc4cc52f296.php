

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto py-6 space-y-8">

    
    <div class="bg-white shadow rounded px-6 py-5">
        <div class="flex items-center justify-between">
            <div>
                <div class="text-sm font-medium text-gray-500">
                    Customer Account
                </div>

                <div class="text-3xl font-bold font-mono text-gray-900 leading-tight">
                    <?php echo e($customer->account_number); ?>

                </div>
            </div>

            <span class="inline-flex items-center px-4 py-1.5 text-sm rounded-full font-semibold
                <?php if($customer->customer_status === 'active'): ?> bg-green-100 text-green-800
                <?php elseif($customer->customer_status === 'on_hold'): ?> bg-yellow-100 text-yellow-800
                <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                <?php echo e(str_replace('_', ' ', $customer->customer_status)); ?>

            </span>
        </div>

        <div class="mt-4 border-t"></div>

        <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="space-y-1">
                <div class="text-lg font-semibold text-gray-900">
                    <?php echo e($customer->contact_name); ?>

                </div>

                <?php if($customer->registered_company_name): ?>
                    <div class="text-sm text-gray-600">
                        <?php echo e($customer->registered_company_name); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="space-y-1 text-sm text-gray-700">
                <?php if($customer->customer_registration_number): ?>
                    <div>
                        <span class="font-medium text-gray-500">Reg No:</span>
                        <?php echo e($customer->customer_registration_number); ?>

                    </div>
                <?php endif; ?>

                <?php if($customer->vat_number): ?>
                    <div>
                        <span class="font-medium text-gray-500">VAT:</span>
                        <?php echo e($customer->vat_number); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="mt-2 text-xs text-gray-500">
        Managed under company:
        <span class="font-medium text-gray-700">
            <?php echo e($customer->company->legal_name); ?>

        </span>
    </div>

    
    <div class="bg-white shadow rounded">
        <div class="border-b p-4 flex justify-between items-center">
            <h2 class="font-semibold">Customer Details</h2>

            
            <a href="<?php echo e(route('customers.edit', $customer)); ?>" class="text-blue-600 text-sm hover:underline">
                Edit Customer
            </a>
        </div>

        <div class="p-6 text-sm">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-3">
                    <div><span class="text-gray-500">Email:</span> <?php echo e($customer->email ?? '—'); ?></div>
                    <div><span class="text-gray-500">Primary Phone:</span> <?php echo e($customer->primary_phone ?? '—'); ?></div>
                    <div><span class="text-gray-500">Secondary Phone:</span> <?php echo e($customer->secondary_phone ?? '—'); ?></div>
                </div>

                <div class="space-y-3">
                    <div><span class="text-gray-500">VAT:</span> <?php echo e($customer->vat_number ?? '—'); ?></div>
                    <div>
                        <span class="text-gray-500">Credit Limit:</span>
                        <?php echo e($customer->credit_limit !== null ? number_format($customer->credit_limit, 2) : '—'); ?>

                    </div>
                    <div>
                        <span class="text-gray-500">Payment Terms:</span>
                        <?php echo e(str_replace('_', ' ', $customer->payment_terms ?? '—')); ?>

                    </div>
                </div>
            </div>

            <?php if($customer->internal_notes): ?>
                <div class="mt-6 pt-6 border-t">
                    <div class="text-gray-500 mb-1">Internal Notes</div>
                    <div class="bg-gray-50 border rounded p-3 whitespace-pre-line">
                        <?php echo e($customer->internal_notes); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    
    <?php echo $__env->make('customers._addresses', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php
        $products = $products ?? \App\Models\Product\Product::with('variations')->orderBy('product_name')->get();
        $portfolio = $portfolio ?? collect();
        $activePortfolioMap = $activePortfolioMap ?? collect();
    ?>

    <?php echo $__env->make('customers._portfolio', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="bg-white shadow rounded p-6">
        <h2 class="font-semibold mb-1">Financial Summary</h2>
        <p class="text-sm text-gray-500">
            Invoices, outstanding balance, overdue amounts, statements.
        </p>
    </div>

    
    <div class="bg-white shadow rounded p-6">
        <h2 class="font-semibold mb-1">Communications</h2>
        <p class="text-sm text-gray-500">
            Messages, notes, emails/calls, and customer-visible communications.
        </p>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sajja\Desktop\new-foamvillage-crm\resources\views/customers/show.blade.php ENDPATH**/ ?>